module("core", { teardown: moduleTeardown });

test("Basic requirements", function() {
    expect(7);
	ok( Array.prototype.push, "Array.push()" );
	ok( Function.prototype.apply, "Function.apply()" );
	ok( document.getElementById, "getElementById" );
	ok( document.getElementsByTagName, "getElementsByTagName" );
	ok( RegExp, "RegExp" );
	ok( jQuery, "jQuery" );
	ok( $, "$" );
});

test("jQuery()", function() {
	expect(29);

//29 assertions
});

test("selector state", function() {
	expect(31);

//31 assrtions

});

test( "globalEval", function() {

	expect( 3 );

	jQuery.globalEval( "var globalEvalTest = true;" );
	ok( window.globalEvalTest, "Test variable declarations are global" );

	window.globalEvalTest = false;

	jQuery.globalEval( "globalEvalTest = true;" );
	ok( window.globalEvalTest, "Test variable assignments are global" );

	window.globalEvalTest = false;

	jQuery.globalEval( "this.globalEvalTest = true;" );
	ok( window.globalEvalTest, "Test context (this) is the window object" );

	window.globalEvalTest = undefined;
});

test("noConflict", function() {
	expect(7);

	var $$ = jQuery;

	equal( jQuery, jQuery.noConflict(), "noConflict returned the jQuery object" );
	equal( jQuery, $$, "Make sure jQuery wasn't touched." );
	equal( $, original$, "Make sure $ was reverted." );

	jQuery = $ = $$;

	equal( jQuery.noConflict(true), $$, "noConflict returned the jQuery object" );
	equal( jQuery, originaljQuery, "Make sure jQuery was reverted." );
	equal( $, original$, "Make sure $ was reverted." );
	ok( $$("#qunit-fixture").html("test"), "Make sure that jQuery still works." );

	jQuery = $$;
});

test("trim", function() {
	expect(9);

	var nbsp = String.fromCharCode(160);

	equal( jQuery.trim("hello  "), "hello", "trailing space" );
	equal( jQuery.trim("  hello"), "hello", "leading space" );
	equal( jQuery.trim("  hello   "), "hello", "space on both sides" );
	equal( jQuery.trim("  " + nbsp + "hello  " + nbsp + " "), "hello", "&nbsp;" );

	equal( jQuery.trim(), "", "Nothing in." );
	equal( jQuery.trim( undefined ), "", "Undefined" );
	equal( jQuery.trim( null ), "", "Null" );
	equal( jQuery.trim( 5 ), "5", "Number" );
	equal( jQuery.trim( false ), "false", "Boolean" );
});

test("type", function() {
	expect(23);
//23 assertions
});

test("isPlainObject", function() {
	expect(15);
//15 assertions
});

test("isFunction", function() {
	expect(19);
	//19 assertions
});

test( "isNumeric", function() {
	expect( 37 );
//37 assertions
});

test("isXMLDoc - HTML", function() {
	expect(4);
//4 assertions
});

test("XSS via location.hash", function() {
	expect(1);
//1 assertions
});

test("isWindow", function() {
	expect( 14 );
//14 assertions
});

test("jQuery('html')", function() {
	expect(18);

//18 assertions
});

test("jQuery('html', context)", function() {
	expect(1);

	var $div = jQuery("<div/>")[0];
	var $span = jQuery("<span/>", $div);
	equal($span.length, 1, "Verify a span created with a div context works, #1763");
});
test("end()", function() {
	expect(3);
	equal( "Yahoo", jQuery("#yahoo").parent().end().text(), "Check for end" );
	ok( jQuery("#yahoo").end(), "Check for end with nothing to end" );

	var x = jQuery("#yahoo");
	x.parent();
	equal( "Yahoo", jQuery("#yahoo").text(), "Check for non-destructive behaviour" );
});

test("length", function() {
	expect(1);
	equal( jQuery("#qunit-fixture p").length, 6, "Get Number of Elements Found" );
});

test("size()", function() {
	expect(1);
	equal( jQuery("#qunit-fixture p").size(), 6, "Get Number of Elements Found" );
});

test("get()", function() {
	expect(1);
	deepEqual( jQuery("#qunit-fixture p").get(), q("firstp","ap","sndp","en","sap","first"), "Get All Elements" );
});

test("toArray()", function() {
	expect(1);
	deepEqual( jQuery("#qunit-fixture p").toArray(),
		q("firstp","ap","sndp","en","sap","first"),
		"Convert jQuery object to an Array" )
})

test("inArray()", function() {
	expect(19);

//19 assertions

});

test("get(Number)", function() {
	expect(2);
	equal( jQuery("#qunit-fixture p").get(0), document.getElementById("firstp"), "Get A Single Element" );
	strictEqual( jQuery("#firstp").get(1), undefined, "Try get with index larger elements count" );
});

test("get(-Number)",function() {
	expect(2);
	equal( jQuery("p").get(-1), document.getElementById("first"), "Get a single element with negative index" );
	strictEqual( jQuery("#firstp").get(-2), undefined, "Try get with index negative index larger then elements count" );
})

test("each(Function)", function() {
	expect(1);
	var div = jQuery("div");
	div.each(function(){this.foo = "zoo";});
	var pass = true;
	for ( var i = 0; i < div.size(); i++ ) {
		if ( div.get(i).foo != "zoo" ) pass = false;
	}
	ok( pass, "Execute a function, Relative" );
});

test("slice()", function() {
	expect(7);

	var $links = jQuery("#ap a");

	deepEqual( $links.slice(1,2).get(), q("groups"), "slice(1,2)" );
	deepEqual( $links.slice(1).get(), q("groups", "anchor1", "mark"), "slice(1)" );
	deepEqual( $links.slice(0,3).get(), q("google", "groups", "anchor1"), "slice(0,3)" );
	deepEqual( $links.slice(-1).get(), q("mark"), "slice(-1)" );

	deepEqual( $links.eq(1).get(), q("groups"), "eq(1)" );
	deepEqual( $links.eq("2").get(), q("anchor1"), "eq('2')" );
	deepEqual( $links.eq(-1).get(), q("mark"), "eq(-1)" );
});

test("first()/last()", function() {
	expect(4);

	var $links = jQuery("#ap a"), $none = jQuery("asdf");

	deepEqual( $links.first().get(), q("google"), "first()" );
	deepEqual( $links.last().get(), q("mark"), "last()" );

	deepEqual( $none.first().get(), [], "first() none" );
	deepEqual( $none.last().get(), [], "last() none" );
});

test("map()", function() {
	expect(8);

	deepEqual(
		jQuery("#ap").map(function(){
			return jQuery(this).find("a").get();
		}).get(),
		q("google", "groups", "anchor1", "mark"),
		"Array Map"
	);

	deepEqual(
		jQuery("#ap > a").map(function(){
			return this.parentNode;
		}).get(),
		q("ap","ap","ap"),
		"Single Map"
	);

	//for #2616
	var keys = jQuery.map( {a:1,b:2}, function( v, k ){
		return k;
	});
	equal( keys.join(""), "ab", "Map the keys from a hash to an array" );

	var values = jQuery.map( {a:1,b:2}, function( v, k ){
		return v;
	});
	equal( values.join(""), "12", "Map the values from a hash to an array" );

	// object with length prop
	var values = jQuery.map( {a:1,b:2, length:3}, function( v, k ){
		return v;
	});
	equal( values.join(""), "123", "Map the values from a hash with a length property to an array" );

	var scripts = document.getElementsByTagName("script");
	var mapped = jQuery.map( scripts, function( v, k ){
		return v;
	});
	equal( mapped.length, scripts.length, "Map an array(-like) to a hash" );

	var nonsense = document.getElementsByTagName("asdf");
	var mapped = jQuery.map( nonsense, function( v, k ){
		return v;
	});
	equal( mapped.length, nonsense.length, "Map an empty array(-like) to a hash" );

	var flat = jQuery.map( Array(4), function( v, k ){
		return k % 2 ? k : [k,k,k];//try mixing array and regular returns
	});
	equal( flat.join(""), "00012223", "try the new flatten technique(#2616)" );
});

test("jQuery.merge()", function() {
	expect(8);

	var parse = jQuery.merge;

	deepEqual( parse([],[]), [], "Empty arrays" );

	deepEqual( parse([1],[2]), [1,2], "Basic" );
	deepEqual( parse([1,2],[3,4]), [1,2,3,4], "Basic" );

	deepEqual( parse([1,2],[]), [1,2], "Second empty" );
	deepEqual( parse([],[1,2]), [1,2], "First empty" );

	// Fixed at [5998], #3641
	deepEqual( parse([-2,-1], [0,1,2]), [-2,-1,0,1,2], "Second array including a zero (falsy)");

	// After fixing #5527
	deepEqual( parse([], [null, undefined]), [null, undefined], "Second array including null and undefined values");
	deepEqual( parse({length:0}, [1,2]), {length:2, 0:1, 1:2}, "First array like");
});

test("jQuery.extend(Object, Object)", function() {
	expect(28);

	//28 assertions
});

test("jQuery.each(Object,Function)", function() {
	expect(14);
//14 assertions
});

test("jQuery.makeArray", function(){
	expect(17);

//17 assertions
});

test("jQuery.inArray", function(){
	expect(3);

	equal( jQuery.inArray( 0, false ), -1 , "Search in 'false' as array returns -1 and doesn't throw exception" );

	equal( jQuery.inArray( 0, null ), -1 , "Search in 'null' as array returns -1 and doesn't throw exception" );

	equal( jQuery.inArray( 0, undefined ), -1 , "Search in 'undefined' as array returns -1 and doesn't throw exception" );
});

test("jQuery.isEmptyObject", function(){
	expect(2);

	equal(true, jQuery.isEmptyObject({}), "isEmptyObject on empty object literal" );
	equal(false, jQuery.isEmptyObject({a:1}), "isEmptyObject on non-empty object literal" );

	
});

test("jQuery.proxy", function(){
	expect(7);
//7 assertions
});

test("jQuery.parseJSON", function(){
	expect(8);

//8 assertions
});

test("jQuery.sub() - Static Methods", function(){
    expect(18);
//18 assertions
});

test("jQuery.sub() - .fn Methods", function(){
	expect(378);
//378 assertions

});

test("jQuery.camelCase()", function() {

	var tests = {
		"foo-bar": "fooBar",
		"foo-bar-baz": "fooBarBaz",
		"girl-u-want": "girlUWant",
		"the-4th-dimension": "the4thDimension",
		"-o-tannenbaum": "OTannenbaum",
		"-moz-illa": "MozIlla",
		"-ms-take": "msTake"
	};

	expect(7);

	jQuery.each( tests, function( key, val ) {
		equal( jQuery.camelCase( key ), val, "Converts: " + key + " => " + val );
	});
});
